package com.example.jsonprocessing.productShop.services;

public interface CategoryService {

}
