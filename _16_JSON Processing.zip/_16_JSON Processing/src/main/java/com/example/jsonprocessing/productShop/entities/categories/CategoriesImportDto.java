package com.example.jsonprocessing.productShop.entities.categories;

public class CategoriesImportDto {
    private String name;

    public String getName() {
        return name;
    }
}
