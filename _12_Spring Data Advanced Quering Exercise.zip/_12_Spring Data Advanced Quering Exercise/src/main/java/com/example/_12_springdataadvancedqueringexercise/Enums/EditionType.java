package com.example._12_springdataadvancedqueringexercise.Enums;

public enum EditionType {
    NORMAL,
    PROMO,
    GOLD
}
