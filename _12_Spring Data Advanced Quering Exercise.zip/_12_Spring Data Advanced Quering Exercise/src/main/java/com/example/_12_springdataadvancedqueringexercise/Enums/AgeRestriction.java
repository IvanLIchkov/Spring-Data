package com.example._12_springdataadvancedqueringexercise.Enums;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
