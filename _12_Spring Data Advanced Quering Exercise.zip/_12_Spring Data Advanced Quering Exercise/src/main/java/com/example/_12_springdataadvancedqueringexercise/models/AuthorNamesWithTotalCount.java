package com.example._12_springdataadvancedqueringexercise.models;

public interface AuthorNamesWithTotalCount {
     String getFirstName();
     String getLastName();
     long getTotalCopies();

}
