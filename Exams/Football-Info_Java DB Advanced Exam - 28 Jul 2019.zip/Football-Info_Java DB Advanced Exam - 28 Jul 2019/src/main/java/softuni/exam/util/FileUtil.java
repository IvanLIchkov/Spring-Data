package softuni.exam.util;


import java.io.IOException;

public interface FileUtil {

    String readFile(String filePath) throws IOException;
}
