create
    definer = root@localhost procedure usp_get_holders_with_balance_higher_than(IN over_number decimal(19, 4))
BEGIN
	SELECT `first_name`, `last_name` FROM `account_holders`
    WHERE (SELECT ufn_get_holder_balance(`id`)) > `over_number`
    ORDER BY `id`;
END;

