create
    definer = root@localhost procedure usp_raise_salaries(IN department_name varchar(50))
BEGIN
	UPDATE `employees` SET `salary` = `salary` * 1.05
    WHERE `department_id` =(
		SELECT `department_id` FROM `departments`
        WHERE `name` = `department_name`
    );
END;

