create
    definer = root@localhost function ufn_count_employees_by_town_fun(town_name varchar(20)) returns int deterministic
BEGIN
	DECLARE e_count INT;
    SET e_count :=(SELECT COUNT(employee_id) FROM employees AS `e`
		JOIN addresses AS `a` ON `a`.`address_id` = `e`.`address_id`
        JOIN towns AS `t` ON `t`.`town_id` = `a`.`town_id`
	WHERE `t`.`name` = town_name);
	RETURN e_count;
END;

