create
    definer = root@localhost function ufn_get_salary_level(salary decimal(19, 2)) returns varchar(10) deterministic
BEGIN
		DECLARE `level` VARCHAR(10);
		
		IF (`salary` < 30000) THEN SET `level` = 'Low';
        ELSEIF (`salary`>=30000 && `salary`<=50000) THEN SET `level` = 'Average';
        ELSE SET `level` = 'High';
        END IF;
        RETURN `level`;
END;

