create
    definer = root@localhost procedure usp_withdraw_money(IN account_id int, IN money_amount decimal(19, 4))
BEGIN
	update `accounts` AS a SET `balance`=(`balance` - `money_amount`)
    WHERE a.id = account_id AND money_amount>0 AND  balance-money_amount >=0;
    SELECT * FROM accounts
    where id = account_id;
 END;

