create
    definer = root@localhost function ufn_get_holder_balance(id int) returns decimal(19, 4) deterministic
BEGIN
	RETURN(SELECT SUM(`balance`) FROM `accounts` AS a
    WHERE a.`account_holder_id` = `id`
    GROUP BY a.`account_holder_id`);
END;

