create
    definer = root@localhost procedure usp_get_towns_starting_with(IN starting_string varchar(50))
BEGIN
	SELECT `name` AS `town_name` FROM `towns`
    WHERE `name` LIKE CONCAT(`starting_string`, '%')
    ORDER BY `name`;
END;

