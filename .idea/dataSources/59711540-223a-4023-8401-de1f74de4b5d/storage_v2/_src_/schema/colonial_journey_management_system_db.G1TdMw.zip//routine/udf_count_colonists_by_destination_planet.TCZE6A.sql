create
    definer = root@localhost function udf_count_colonists_by_destination_planet(planet_name varchar(30)) returns int
    deterministic
BEGIN
	RETURN(
		SELECT COUNT(*) FROM colonists AS c
JOIN
	travel_cards AS tc ON tc.colonist_id = c.id
JOIN
	journeys AS j ON j.id = tc.journey_id
JOIN 
	spaceports AS sp ON sp.id = j.destination_spaceport_id
JOIN 
	planets AS p ON p.id = sp.planet_id
WHERE p.name LIKE planet_name
    );
END;

