create
    definer = root@localhost procedure usp_get_older(IN minion_id int)
begin
    UPDATE minions
    SET age = age+1
    WHERE id = minion_id;

    select name, age from minions
        where id = minion_id;
end;

