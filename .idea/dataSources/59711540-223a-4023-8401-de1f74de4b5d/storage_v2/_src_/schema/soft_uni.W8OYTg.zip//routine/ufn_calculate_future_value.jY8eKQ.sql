create
    definer = root@localhost function ufn_calculate_future_value(sum decimal(19, 4), y_rate double, years int) returns decimal(19, 4)
    deterministic
BEGIN
	RETURN `sum`*(POWER(1+`y_rate`, `years`));
END;

