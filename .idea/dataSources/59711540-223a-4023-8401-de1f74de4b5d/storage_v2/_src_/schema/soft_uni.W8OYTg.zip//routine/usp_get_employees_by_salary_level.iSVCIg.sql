create
    definer = root@localhost procedure usp_get_employees_by_salary_level(IN level varchar(10))
BEGIN
	SELECT `first_name`, `last_name` FROM `employees`
    WHERE (SELECT ufn_get_salary_level(`salary`)) LIKE `level`
    ORDER BY `first_name` DESC,`last_name`DESC;
END;

