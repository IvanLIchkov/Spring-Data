create
    definer = root@localhost procedure udp_find_playmaker(IN min_dribble_points int, IN team_name varchar(45))
begin
	SELECT CONCAT_WS(" ",p.first_name, p.last_name) AS full_name, p.age, p.salary, sd.dribbling, sd.speed, t.`name` from players as p
    join skills_data as sd on sd.id = p.skills_data_id
    join teams as t on t.id = p.team_id
    where sd.dribbling > min_dribble_points and t.`name` like team_name
    order by sd.speed desc
    limit 1;
end;

