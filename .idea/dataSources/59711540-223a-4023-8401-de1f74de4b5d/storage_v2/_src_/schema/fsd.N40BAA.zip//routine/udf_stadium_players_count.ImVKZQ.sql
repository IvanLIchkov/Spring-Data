create
    definer = root@localhost function udf_stadium_players_count(stadium_name varchar(30)) returns int deterministic
begin 
RETURN(	SELECT COUNT(*) from stadiums as s
join teams as t on t.stadium_id = s.id
join players as p on p.team_id = t.id
where s.`name` like stadium_name);
end;

