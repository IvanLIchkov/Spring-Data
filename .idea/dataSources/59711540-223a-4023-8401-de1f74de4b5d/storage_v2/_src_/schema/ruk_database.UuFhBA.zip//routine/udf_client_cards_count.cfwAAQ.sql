create
    definer = root@localhost function udf_client_cards_count(name varchar(30)) returns int deterministic
begin
	return(select count(card.id) as cars from clients as c
    join bank_accounts as ba on ba.client_id = c.id
   join cards as card on card.bank_account_id = ba.id
   where c.full_name = name);
end;

