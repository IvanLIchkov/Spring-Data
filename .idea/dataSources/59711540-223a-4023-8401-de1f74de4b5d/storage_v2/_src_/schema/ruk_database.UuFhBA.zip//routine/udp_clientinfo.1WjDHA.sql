create
    definer = root@localhost procedure udp_clientinfo(IN full_name varchar(50))
begin
	select c.full_name, c.age, ba.account_number, concat_ws("","$", ba.balance) as balance from clients as c
    join bank_accounts ba on ba.client_id = c.id
    where c.full_name LIKE full_name;
end;

