package com.product_shop.services;

import com.product_shop.entities.categories.ExportCategoriesDto;

public interface CategoryService {

    ExportCategoriesDto findAllCategoriesCount();
}
