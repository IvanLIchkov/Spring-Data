package com.example.bookshopsystem.Enums;

public enum EditionType {
    NORMAL,
    PROMO,
    GOLD
}
