package com.example.bookshopsystem.services;

public class BookService {
}
