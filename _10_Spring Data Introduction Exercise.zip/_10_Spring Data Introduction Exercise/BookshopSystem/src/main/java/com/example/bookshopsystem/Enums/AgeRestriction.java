package com.example.bookshopsystem.Enums;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
