package com.usersystem.usersystem.anotations;

public @interface Password {
}
